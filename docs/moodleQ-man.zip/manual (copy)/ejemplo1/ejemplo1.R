# -------------------------------------------
#   Miguel A. Castellanos
# -------------------------------------------

# Fecha:
# Descripcion:
# -------------------------------------------


# Ejemplo 1
# lee el fichero de preguntas y lo pasa a quiz


library(moodleQ)

lines <- readLines("./preguntas.md")

Q <- quiz$new()

nq = 0; i=1
while(i<=length(lines)){
  if(lines[i]=="") i = i + 1
  else if(grepl("category", lines[i])){
    nq = nq + 1
    Q$add(
      question$new(
        'type' = "category",
        'name' = sprintf("P%03d",nq),
        'category' = sprintf("$course$/%s", strsplit(lines[i], " ")[[1]][[2]])))
    i = i + 1
  } else {
    nq = nq + 1
    q <- question$new(type="multichoice", 
                      'name' = sprintf("P%03d",nq),
                      'format' = 'markdown',
                      'question' = lines[i],
                      'answer' = list(lines[i+1], 100))
    j = i+2
    while(lines[j]!="" & j <= length(lines)){
      q$addanswer(list(lines[j]))
      j = j + 1
    }
    Q$add(q)
    i = j
  }
}

Q$save_xml("ejemplo1.xml")
