library(moodleQ)

# ---------------------------------------------------------------------------

q1 <- question$new(
  type="multichoice",
  'name' = "P001",
  'question' = "This is the question text",
  'answer' = list("Answer #1", 100),
  'answer' = list("Answer #2"),
  'answer' = list("Answer #3"))

Q <- quiz$new(q1)
Q$save_xml("mifichero.xml")



# ---------------------------------------------------------------------------
q0 <- question$new(
  type="category",
  'name' = 'P000',
  'category' = "$course$/moodleQ_test")

q1 <- question$new(
  type="multichoice",
  'name' = "P001",
  'question' = "This is the question text",
  'single' = 'false',
  'shuffleanswers' = 0,
  'answernumbering' = 'none',
  'answer' = list("Answer #1", 100),
  'answer' = list("Answer #2"),
  'answer' = list("Answer #3"))

Q <- quiz$new(q1)
Q$save_xml("mifichero2.xml")


# ---------------------------------------------------------------------------
q1 <- question$new(
  type="multichoice")

q1$set('name' = "Q001",
       'question' = "This is the question text")

q1$addanswer(list("Answer #1", 100))$
   addanswer(list("Answer #2"))$ 
   addanswer(list("Answer #3"))

q1$xml()
# ---------------------------------------------------------------------------

q0 <- question$new(
  type="category",
  'name' = 'P000',
  'category' = "$course$/pruebas_moodleQ")

q1 <- question$new(
  type="multichoice",
  'name' = "P001",
  'question' = "Enunciado",
  'answer' = list("Alternativa 1", 100),
  'answer' = list("Alternativa 2"),
  'answer' = list("Alternativa 3"))

Q <- quiz$new(q0, q1)
Q$xml()

# ---------------------------------------------------------------------------
# Todos los tipos de preguntas

q0 <- question$new(
  type="category",
  'name' = 'Q000',
  'category' = "$course$/test_moodleQ")

q1 <- question$new(
  type="multichoice",
  'name' = "Q001",
  'question' = "This is the question text",
  'answer' = list("Answer #1", 100),
  'answer' = list("Answer #2"),
  'answer' = list("Answer #3"))

q3 <- question$new(
  type="description",
  'name' = 'Q003',
  'question' = 'This is a very long question text explaining interesting things')

q5 <- question$new(
  type='truefalse',
  'name' = "P005",
  'question' = 'This is a question text for true/false questions',
  'answer' = list("true", 100),
  'answer' = list("false", 0),
)

q6 <- question$new(
  type="shortanswer",
  'name' = "P006",
  'question' = 'This is a question text for shoranswer questions',
  'answer' = list("This is the right answer", 100),
  'answer' = list("This is the ALMOST right answer", 90)
)

q7 <- question$new(
  type="numerical",
  'name' = "P007",
  'question' = 'This is a question text for numerical questions',
  'answer' = list(17, 100)
)

Q <- quiz$new(q0, q1, q3, q5, q6, q7)
Q$save_xml("mifichero3.xml")

# ---------------------------------------------------------------------------
# Uso de formatos

library(moodleQ)

q0 <- question$new(
  type="category",
  'name' = 'Q000',
  'category' = "$course$/test_moodleQ")

q1 <- question$new(
  type="description",
  'name' = 'Q001',
  'question' = '
<h1>Heading #1</h1>
<h2>Heading #2</h2>
<bold>bold text </bold>
<i>italic</i>
<u><li>one</li> <li>two</li></u>
<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc id fringilla diam, id lobortis eros. Quisque consequat ultricies enim, nec interdum nisl dignissim sit amet. Pellentesque quis erat non odio cursus porta </p>
  ')

q2 <- question$new(
  type="description",
  'name' = 'Q002',
  'format' = 'markdown',
  'question' = '
#Heading #1

##Heading #2

**bold text**

*italic*

* one
* two

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc id fringilla diam, id lobortis eros. Quisque consequat ultricies enim, nec interdum nisl dignissim sit amet. Pellentesque quis erat non odio cursus porta
  ')

Q <- quiz$new(q0, q1, q2)
Q$save_xml("mifichero4.xml")


# ----------------------------------------------------------------
# a vueltasa con las formulas

q0 <- question$new(
  type="category",
  'name' = 'Q000',
  'category' = "$course$/test_moodleQ")


q1 <- question$new(
  type="description",
  'name' = 'Q001',
  'question' = '
<p>This is an inline equation:  \\[ \\alpha = 2*\\beta \\] </p>
<p>This equation is in a different line</p>
\\( \\alpha = \\frac{2}{\\beta} \\)
  ')


q2 <- question$new(
  type="description",
  'name' = "Q002",
  'format' = 'markdown',
  'question' = '
 This is an inline equation:  \\[ \\alpha = 2*\\beta \\] 
  
 This equation is in a different line
 
 \\( \\alpha = \\frac{2}{\\beta} \\)
  ')

Q <- quiz$new(q0, q1, q2)
Q$save_xml("mifichero5.xml")


# ---------------------------------------------------------------------------

q0 <- question$new(
  type="category",
  'name' = 'Q000',
  'category' = "$course$/test_moodleQ")


# Incrusta ficheros
q1 <- question$new(
  type="multichoice",
  'name' = "P001",
  'question' = '
  Choose: 
<u>
<li><a href="@@PLUGINFILE@@/A.csv">download A.csv</a></li>
<li><a href="@@PLUGINFILE@@/B.csv">download B.csv</a></li> 
<li><a href="@@PLUGINFILE@@/C.csv">download C.csv</a></li>
</u>
  ',
  'answer' = list("Answer 1", 100),
  'answer' = list("Answer 2"))



q1$addfile("./file.csv", "A.csv")
q1$addfile("./file.csv", "B.csv")

df <- data.frame(a = rnorm(10), b=rnorm(10))

tmp <- tempfile()
write.table(df, file=tmp, sep=",", dec=".")
q1$addfile(tmp, "C.csv")
unlink(tmp)
q1$xml()

Q <- quiz$new(q0, q1)
Q$save_xml("mifichero6.xml")

# ---------------------------------------------------------------------------
# Crea bancos de respuestas

q0 <- question$new(
  type="category",
  'name' = 'Q000',
  'category' = "$course$/test_moodleQ")

q1 <- question$new(
  type="calculated",
  'name' = "P001",
  'question' = "
  With the numbers: A = {A} and B = {B}
  
  
  <p>Calculate: A + B</p>
  
  ",
  'answer' = list("{C}", 100),
  'dataset' = list(data.frame(A = c(1, 4))),
  'dataset' = list(data.frame(B = c(3, 2))),  
  'dataset' = list(data.frame(C = c(4,6))))                

q2 <- question$new(
  type="calculated",
  'name' = "P002",
  'question' = "Calculate A * B",
  'answer' = list("{D}", 100),
  'dataset' = list(data.frame(D = c(3,8))))


q3 <- question$new(
  type="calculated",
  'name' = "P001",
  'question' = "
Calcule A - B. 
<hr>
<p>Write in the answer box the number of the right statement:</p>
<u>
<li><b>1</b> = The result is positive</li>
<li><b>2</b> = The result is negative</li>
</u>  
  ",
  'answer' = list("{E}", 100),
  'dataset' = list(data.frame(E = c(2, 1))))

                              
Q <- quiz$new(q0, q1, q2, q3)
Q$save_xml("mifichero7.xml")

# ---------------------------------------------------------------------------
# Ejemplo 1
# lee el fichero de preguntas y lo pasa a quiz
library(moodleQ)

lines <- readLines("./preguntas.md")

Q <- quiz$new()

nq = 0; i=1
while(i<=length(lines)){
  if(lines[i]=="") i = i + 1
  else if(grepl("category", lines[i])){
    nq = nq + 1
    Q$add(
      question$new(
        'type' = "category",
        'name' = sprintf("P%03d",nq),
        'category' = sprintf("$course$/%s", strsplit(lines[i], " ")[[1]][[2]])))
    i = i + 1
  } else {
    nq = nq + 1
    q <- question$new(type="multichoice", 
            'name' = sprintf("P%03d",nq),
            'format' = 'markdown',
            'question' = lines[i],
            'answer' = list(lines[i+1], 100))
    j = i+2
    while(lines[j]!="" & j <= length(lines)){
      q$addanswer(list(lines[j]))
      j = j + 1
    }
    Q$add(q)
    i = j
  }
}

Q$save_xml("mifichero8.xml")

# ---------------------------------------------------------------------
# Ejemplo 2
# Creamos un enunciado común


library(moodleQ)


# Un enunciado usando html
myquestiontext = '
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent egestas urna a dapibus imperdiet. Quisque augue neque, ornare pharetra facilisis ut, ultricies eu magna. Nulla facilisi. Quisque eget metus lectus. Integer pharetra sagittis luctus. Sed vel nisi eu arcu sollicitudin venenatis non vel nisi. Ut enim felis, commodo eu iaculis in, tempus in ipsum. Proin viverra ultrices laoreet. Nunc id sollicitudin diam, at faucibus massa. Mauris dapibus lorem ipsum, et condimentum eros mattis sit amet. Phasellus tempor velit odio, non eleifend eros molestie non.

Download this pdf: [reading.pdf](@@PLUGINFILE@@/reading.pdf)
'

q0 <- question$new(
  type="category",
  'name' = 'P000',
  'category' = "$course$/Ejemplo2")


q1 <- question$new(
  type="description",
  'name' = 'P001',
  'question' = myquestiontext,
  'format' = 'markdown',
  'file' = list("./reading.pdf"))

# ahora un par de preguntas

q2 <- question$new(
  type="multichoice",
  'name' = "P002",
  'question' = "Question #1 about reading.pdf",
  'answer' = list("Yes", 100),
  'answer' = list("No"),
  'answer' = list("Who knows"))

q3 <- question$new(
  type='truefalse',
  'name' = "P003",
  'question' = 'Question #2 about reading.pdf',
  'answer' = list("true", 100),
  'answer' = list("false"),
)

Q <- quiz$new(q0, q1, q2, q3)
Q$save_xml("mifichero9.xml")

# ----------------------------------------------------------------
# Ejemplo 3.

### OJO: No funciona porque los wildcards (tokens) solo pueden ser numeros
# Nunca cadenas o vectores

# library(moodleQ)
# 
# m <- matrix(sample(1:10, 100, replace=T), nrow=10)
# 
# q0 <- question$new(
#   type="category",
#   'name' = 'P000',
#   'category' = "$course$/ejemplo3")
# 
# 
# q1 <- question$new(
#   type="calculated",
#   'name' = "P001",
#   'question' = "
# With this vector: {DATA}
# 
# Calculate the mean:
#   ",
#   'format' = 'markdown',
#   'answer' = list("{MEAN}", 100),
#   'dataset' = list(data.frame(DATA = apply(m,1,toString))),
#   'dataset' = list(data.frame(MEAN = apply(m, 1, mean))))
# 
# q2 <- question$new(
#   type="calculated",
#   'name' = "P002",
#   'question' = "
#     Calculate the standard deviation:",
#   'answer' = list("{SD}", 100),
#   'dataset' = list(data.frame(SD = apply(m,1,sd))))
# 
# q3 <- question$new(
#   type="calculated",
#   'name' = "P003",
#   'question' = "
#     Calculate the median:",
#   'answer' = list("{MEDIAN}", 100),
#   'dataset' = list(data.frame(MEDIAN = apply(m,1,median))))
# 
# Q <- quiz$new(q0, q1, q2, q3)
# Q$save_xml("mifichero10.xml")

# ----------------------------------------------------------------
# Ejemplo 4.

library(moodleQ)


data <- list()
for(i in 1:10) data[[i]] <- data.frame(X = rnorm(10), Y = rnorm(10))

results <- data.frame(
  FILE = sample(1000000:9999999, 10),
  COR = unlist(lapply(data, function(x) cor(x$X,x$Y))),
  TTEST.t = as.vector(unlist(lapply(data, function(x) t.test(x$X,x$Y)$statistic))),
  TTEST.gl = as.vector(unlist(lapply(data, function(x) t.test(x$X,x$Y)$parameter))),
  TTEST.pvalue = as.vector(unlist(lapply(data, function(x) t.test(x$X,x$Y)$p.value))) )

q0 <- question$new(
  type="category",
  'name' = 'P000',
  'category' = "$course$/ejemplo1")


q1 <- question$new(
  type="calculated",
  'name' = "P001",
  'format' = 'markdown',
  'question' = '
Download this .csv dataset: [ID_{FILE}.csv](@@PLUGINFILE@@/ID_{FILE}.csv)
    
Calculate the correlation:',
  'answer' = list("{COR}", 100),
  'dataset' = list(data.frame(FILE = results$FILE  )),
  'dataset' = list(data.frame(COR = results$COR  )) )

# incrustamos los ficheros
for (i in 1:10){
  tmp <- tempfile()
  write.table(data[[i]], file=tmp, sep=",", dec=".")
  q1$addfile(tmp, sprintf("ID_%d.csv", results$FILE[i]))
  unlink(tmp)
}


q2 <- question$new(
  type="calculated",
  'name' = "P002",
  'question' = "
    Calculate a t.test and write the statistic (t) value:",
  'answer' = list("{TTEST.t}", 100),
  'dataset' = list(data.frame(TTEST.t = results$TTEST.t  )) )


q3 <- question$new(
  type="calculated",
  'name' = "P003",
  'question' = "
    Write the degree of freedom:",
  'answer' = list("{TTEST.gl}", 100),
  'dataset' = list(data.frame(TTEST.gl = results$TTEST.gl  )) )

q4 <- question$new(
  type="calculated",
  'name' = "P004",
  'question' = "
    Write the p-value:",
  'answer' = list("{TTEST.pvalue}", 100),
  'dataset' = list(data.frame(TTEST.pvalue = results$TTEST.pvalue  )) )

Q <- quiz$new(q0, q1, q2, q3, q4)
Q$xml()

Q$save_xml("mifichero11.xml")

