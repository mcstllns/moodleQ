# -------------------------------------------
#   Miguel A. Castellanos
# -------------------------------------------

# Fecha:
# Descripcion:
# -------------------------------------------

library(moodleQ)


data <- list()
for(i in 1:10) data[[i]] <- data.frame(X = rnorm(10), Y = rnorm(10))

results <- data.frame(
  FILE = sample(1000000:9999999, 10),
  COR = unlist(lapply(data, function(x) cor(x$X,x$Y))),
  TTEST.t = as.vector(unlist(lapply(data, function(x) t.test(x$X,x$Y)$statistic))),
  TTEST.gl = as.vector(unlist(lapply(data, function(x) t.test(x$X,x$Y)$parameter))),
  TTEST.pvalue = as.vector(unlist(lapply(data, function(x) t.test(x$X,x$Y)$p.value))) )

q0 <- question$new(
  type="category",
  'name' = 'P000',
  'category' = "$course$/ejemplo1")


q1 <- question$new(
  type="calculated",
  'name' = "P001",
  'format' = 'markdown',
  'question' = '
Download this .csv dataset: [ID_{FILE}.csv](@@PLUGINFILE@@/ID_{FILE}.csv)
    
Calculate the correlation:',
  'answer' = list("{COR}", 100),
  'dataset' = list(data.frame(FILE = results$FILE  )),
  'dataset' = list(data.frame(COR = results$COR  )) )

# incrustamos los ficheros
for (i in 1:10){
  tmp <- tempfile()
  write.table(data[[i]], file=tmp, sep=",", dec=".")
  q1$addfile(tmp, sprintf("ID_%d.csv", results$FILE[i]))
  unlink(tmp)
}


q2 <- question$new(
  type="calculated",
  'name' = "P002",
  'question' = "
    Calculate a t.test and write the statistic (t) value:",
  'answer' = list("{TTEST.t}", 100),
  'dataset' = list(data.frame(TTEST.t = results$TTEST.t  )) )


q3 <- question$new(
  type="calculated",
  'name' = "P003",
  'question' = "
    Write the degree of freedom:",
  'answer' = list("{TTEST.gl}", 100),
  'dataset' = list(data.frame(TTEST.gl = results$TTEST.gl  )) )

q4 <- question$new(
  type="calculated",
  'name' = "P004",
  'question' = "
    Write the p-value:",
  'answer' = list("{TTEST.pvalue}", 100),
  'dataset' = list(data.frame(TTEST.pvalue = results$TTEST.pvalue  )) )

Q <- quiz$new(q0, q1, q2, q3, q4)
Q$xml()

Q$save_xml("ejemplo3.xml")

