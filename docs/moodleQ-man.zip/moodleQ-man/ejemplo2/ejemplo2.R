# -------------------------------------------
#   Miguel A. Castellanos
# -------------------------------------------

# Fecha:
# Descripcion:
# -------------------------------------------


library(moodleQ)


# Un enunciado usando html
myquestiontext = '
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent egestas urna a dapibus imperdiet. Quisque augue neque, ornare pharetra facilisis ut, ultricies eu magna. Nulla facilisi. Quisque eget metus lectus. Integer pharetra sagittis luctus. Sed vel nisi eu arcu sollicitudin venenatis non vel nisi. Ut enim felis, commodo eu iaculis in, tempus in ipsum. Proin viverra ultrices laoreet. Nunc id sollicitudin diam, at faucibus massa. Mauris dapibus lorem ipsum, et condimentum eros mattis sit amet. Phasellus tempor velit odio, non eleifend eros molestie non.

Download this pdf: [reading.pdf](@@PLUGINFILE@@/reading.pdf)
'

q0 <- question$new(
  type="category",
  'name' = 'P000',
  'category' = "$course$/Ejemplo2")


q1 <- question$new(
  type="description",
  'name' = 'P001',
  'question' = myquestiontext,
  'format' = 'markdown',
  'file' = list("./reading.pdf"))

# ahora un par de preguntas

q2 <- question$new(
  type="multichoice",
  'name' = "P002",
  'question' = "Question #1 about reading.pdf",
  'answer' = list("Yes", 100),
  'answer' = list("No"),
  'answer' = list("Who knows"))

q3 <- question$new(
  type='truefalse',
  'name' = "P003",
  'question' = 'Question #2 about reading.pdf',
  'answer' = list("true", 100),
  'answer' = list("false"),
)

Q <- quiz$new(q0, q1, q2, q3)
Q$save_xml("ejemplo2.xml")
